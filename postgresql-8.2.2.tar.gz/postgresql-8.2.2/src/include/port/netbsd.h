/* $PostgreSQL: pgsql/src/include/port/netbsd.h,v 1.16 2006/10/04 00:30:10 momjian Exp $ */
