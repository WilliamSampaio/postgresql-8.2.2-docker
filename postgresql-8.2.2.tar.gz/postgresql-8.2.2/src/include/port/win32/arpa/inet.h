/* $PostgreSQL: pgsql/src/include/port/win32/arpa/inet.h,v 1.2 2006/03/11 04:38:39 momjian Exp $ */

#include <sys/socket.h>
