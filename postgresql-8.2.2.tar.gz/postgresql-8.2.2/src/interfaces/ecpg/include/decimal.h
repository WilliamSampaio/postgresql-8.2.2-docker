/* $PostgreSQL: pgsql/src/interfaces/ecpg/include/decimal.h,v 1.14 2006/03/11 04:38:39 momjian Exp $ */

#ifndef _ECPG_DECIMAL_H
#define _ECPG_DECIMAL_H

#include <ecpg_informix.h>

typedef decimal dec_t;

#endif   /* ndef _ECPG_DECIMAL_H */
